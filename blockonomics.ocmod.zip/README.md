# opencart3-plugin
  * Blockonomics plugin for OpenCart v3
# Install 
  * Download latest 'blockonomics-opencart.ocmod.zip' file from [releases](https://github.com/blockonomics/opencart3-plugin/releases)
  * Open OpenCart admin page.
  * Navigate to Extenstions->Installer and upload the zip file.
  * Navigate to Extensions->Extenstions and select type "Payments" and install blockonomics extension.
  * Open plugin editing, insert your API key and click Test Setup
