<?php

// Text
$_['text_title']                 = 'Bitcoin';

$_['text_basket']     			 = 'Shopping Cart';
$_['text_checkout']				 = 'Checkout';
$_['text_invoice']      		 = 'Invoice';
